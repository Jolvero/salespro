<?php $__env->startSection('content'); ?>
<h2>Plantilla de <?php echo e(Auth::user()->name); ?></h2>

<div class="card card-body">
    <p><?php echo e($plantilla->plantilla); ?></p>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/plantillas/show.blade.php ENDPATH**/ ?>