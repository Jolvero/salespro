<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo e('/images/recordatorio-index.png'); ?>" alt="">
                <h1><?php echo e($recordatorio->asunto); ?></h1>
            </div>
            <div class="col-md-6 card card-body">
                <?php
                    $fecha = $recordatorio->fecha;
                ?>
                <p><img src="<?php echo e('/images/estatus.png'); ?>" alt=""> Fecha: <formatear-fecha class="text-dark" fecha="<?php echo e($fecha); ?>"></formatear-fecha>
                </p>
                <p><img src="<?php echo e('/images/show-prospecto-user.png'); ?>" alt=""> Prospecto: <span
                        class="font-weight-bold"><?php echo e($recordatorio->Prospecto->nombre); ?></span></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/recordatorios/show.blade.php ENDPATH**/ ?>