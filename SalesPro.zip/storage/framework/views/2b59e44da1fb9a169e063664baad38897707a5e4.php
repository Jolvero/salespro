    <div id="sidemenu" class="menu-collapsed">
        <div id="header">
            <div id="menu-btn" class="mr-5">
                <div class="btn-hamburguer"></div>
                <div class="btn-hamburguer"></div>
                <div class="btn-hamburguer"></div>
            </div>
        </div>
        <a href="<?php echo e(route('inicio.index')); ?>"><img src="<?php echo e('/images/logo.jpeg'); ?>" class="img-fluid" alt=""></a>
        <div id="menu-items" data-aos="fade-right" data-aos-duration="1000" data-aos-delay="200">
            <ul class="list-unstyled components mb-1">
                <li class="">
                    <div class="item-parent py-2">
                        <a href="#submenuSeguimientos" id="cartera"data-toggle="collapse" aria-expanded="false"
                            class="dropdown-toggle sidebar-link collapsed item"><img class="ml-2 item-img mr-3 ml-0"
                                src="<?php echo e('/images/cartera.png'); ?>" alt=""><span
                                class="mt-5 consultar-cartera">Cartera</span></a>
                    </div>
                    <ul class="sidebar-dropdown list-unstyled collapse"id="submenuSeguimientos">
                        <li>
                            <a class="sidebar-item d-flex link link-seguimientos my-2 py-2" id="embarque-index"
                                href="<?php echo e(route('cartera.index')); ?>">
                                <img class="ml-2 item-img mr-3 ml-0" src="<?php echo e('/images/seguimiento.png'); ?>"
                                    alt=""><span class="mt-1 seguimientos">Seguimientos</span>
                            </a>
                        </li>

                        <li><a class="sidebar-item d-flex link link-seguimientos my-2 py-2" id="recordatorio-index"
                                href="<?php echo e(route('clientes.index')); ?>">
                                <img class="ml-2 item-img mr-3 ml-0" src="<?php echo e('/images/prospecto.show.png'); ?>"
                                    alt="">
                                <?php if(Auth::user()->rol_id == 1): ?>
                                    <span class="mt-1 consultar-clientes">Clientes</span>
                                <?php else: ?>
                                    <span class="mt-1 consultar-clientes">Mis Clientes</span>
                                <?php endif; ?>
                            </a>
                        </li>
                    </ul>
                </li>

                


                <li class="mt-2">
                    
                    
                    <ul class="collapse list-unstyled" id="submenuCatalogos">
                        <li>
                            
                        </li>

                    </ul>
                </li>
                

                
            </ul>

            

        <a class="sidebar-item d-flex link link-seguimientos my-2 py-2" id="recordatorio-index"
            href="<?php echo e(route('plantillas.index')); ?>">
            <img class="ml-2 item-img mr-3 ml-0" src="<?php echo e('/images/plantilla.png'); ?>" alt="">
            <span class="mt-1 consultar-clientes font-weight-bold">Plantillas</span>
        </a>

            <a class="sidebar-item d-flex link link-seguimientos my-2 py-2" id="recordatorio-index"
                href="<?php echo e(route('recordatorio.index')); ?>">
                <img class="ml-2 item-img mr-3 ml-0" src="<?php echo e('/images/estatus.png'); ?>" alt=""><span
                    class="mt-1 consultar-recordatorios font-weight-bold ">Recordatorios</span>
            </a>

            <a class="d-flex link item-separator pb-2 item" id="imei" href="<?php echo e(route('correo.mailing')); ?>">
                <img class="ml-2 mr-3 mt-2 item-img" src="<?php echo e('/images/correo.png'); ?>" alt=""> <span
                    class="mt-2 consultar-usuarios">Mailing</span>
            </a>

            <a class="d-flex link item-separator pb-2 item" id="imei" href="<?php echo e(route('usuarios.index')); ?>">
                <img class="ml-2 mr-3 mt-2 item-img" src="<?php echo e('/images/usuario.png'); ?>" alt=""> <span
                    class="mt-2 consultar-usuarios">Usuarios</span>
            </a>

        </div>

    </div>

<?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/panel/panel.blade.php ENDPATH**/ ?>