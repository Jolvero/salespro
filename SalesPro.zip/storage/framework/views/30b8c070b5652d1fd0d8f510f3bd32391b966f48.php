<?php echo e($slot); ?>

<?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>