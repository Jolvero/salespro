<section  class="ml-5 ml-md-0">
    <h3 class="font-weight-bold mb-5 mr-5 mr-md-0 p-3 bg-white border-0 shadow" style="border-radius: 2rem;" data-aos="fade-down" data-aos-duration="1000">Bienvenido/a <?php echo e($nombre); ?></h3>
    <div class="row ml-4 justify-content-center">
        

        <div class="col-md-3 mr-5 mr-md-0">
            <div class="d-flex">
            <div class="card ml-3 border-0 shadow" style="border-radius: 2rem;" data-aos="flip-down" data-aos-duration="2000">
                <div class="card-body">
                        <img src="<?php echo e('/images/clientes.png'); ?>" alt="">
                        <p class="font-weight-bold ml-3 mt-4 text-center"><?php echo e($clientes); ?> Clientes</p>
                    </div>
                </div>
            </div>
        </div>

        <?php
            $dia = date('Y-m-d')
        ?>
        <?php $__currentLoopData = $recordatorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recordatorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($dia == $recordatorio): ?>
            <p>Hola</p>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="col-md-3 mr-5 mr-md-0">
            <div class="d-flex">
            <div class="card ml-3 border-0 shadow" style="border-radius: 2rem;" data-aos="flip-down" data-aos-duration="2000">
                <div class="card-body">
                        <img src="<?php echo e('/images/human-resource.png'); ?>" alt="">
                        <p class="font-weight-bold ml-3 mt-4 text-center"><?php echo e($prospectadores); ?> Prospectadores</p>
                    </div>
                </div>
            </div>
        </div>
</section>

<section class="distribuciones mt-5" data-aos="zoom-in" data-aos-duration="1300">
    <div class="card card-body border-0 shadow" style="border-radius: 2rem;">
    <h2 class="font-weight-bold ml-5">Clientes del Mes</h2>
    <figure class="ml-5 ml-md-0">
        <div id="containerClientes">

        </div>
    </figure>
</div>
    </div>
</section>

<section class="inventario mt-5 pt-3">

        <div class="mt-5 card card-body border-0 shadow" style="border-radius: 2rem;">
            <h2 class="font-weight-bold text-center">Prospectos del mes</h2>

            <figure class="ml-5 ml-md-0">
                <div id="mesProspectos"></div>
            </figure>
        </div>

        
    <div>
        <input type="hidden" value="<?php echo e($recordatorios); ?>" id="recordatorio">
    </div>
</section>

<?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>