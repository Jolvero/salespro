<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/clientes.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('estado')): ?>

<div class="alert alert-danger text-center" role="alert">
    <?php echo e(session('estado')); ?>

</div>

<?php endif; ?>
<div class="row">
    <div class="col-md-6 ml-5 ml-md-0 border-bottom border-lg">
        <h1>Editar <?php echo e($cliente->nombre); ?></h1>
        <img src="<?php echo e('/images/clientes.png'); ?>" class="ml-5 my-2" alt="">
    </div>
</div>

    <form action="<?php echo e(route('cliente.update', ['cliente' => $cliente->id])); ?>" method="POST" id="formulario-clientes">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center">
    <div class="col-md-6 mt-5">
        <div class="form-group">
            <img src="<?php echo e('/images/nombre.png'); ?>" alt=""class="mr-1 mb-3">
            <label for="cliente">Cliente <span class="text-danger">*</span> </label>
            <input type="text" name="cliente" id="cliente" class="form-control <?php $__errorArgs = ['clientw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($cliente->nombre); ?>">
            <?php $__errorArgs = ['cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6 mt-5">
        <div class="form-group">
            <img src="<?php echo e('/images/documento.png'); ?>" alt=""class="mr-1 mb-3">
            <label for="rfc">RFC</label>
            <input type="text" name="rfc" id="rfc" class="form-control <?php $__errorArgs = ['rfc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($cliente->rfc); ?>">
            <?php $__errorArgs = ['rfc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6 mt-5">
        <div class="form-group">
            <img src="<?php echo e('/images/direccion.png'); ?>" alt=""class="mr-1 mb-3">
            <label for="direccion">Dirección</label>
            <input type="text" name="direccion" id="direccion" class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($cliente->direccion); ?>">
            <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6 mt-5">
        <div class="form-group">
            <img src="<?php echo e('/images/empresa.png'); ?>" alt=""class="mr-1 mb-3">
            <label for="empresa">Empresa <span class="text-danger">*</label>
            <input type="text" name="empresa" id="empresa" class="form-control <?php $__errorArgs = ['empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($cliente->empresa); ?>">
            <?php $__errorArgs = ['empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6 mt-5">
        <div class="form-group">
            <img src="<?php echo e('/images/correo.png'); ?>" alt=""class="mr-1 mb-3">
            <label for="correo">Correo <span class="text-danger">*</label>
            <input type="text" name="correo" id="correo" class="form-control <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($cliente->correo); ?>">
            <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6 mt-5">
        <div class="form-group">
            <img src="<?php echo e('/images/comentario.png'); ?>" alt=""class="mr-1 mb-3">
            <label for="observaciones">observaciones</label>
            <textarea type="text" name="observaciones" id="observaciones" class="form-control <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10" ><?php echo e($cliente->observaciones); ?></textarea>
            <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group d-block mt-5">
        <button type="submit"  style="background-color:#1973b8; border:none;" type="submit" class="boton text-white p-3 rounded d-block mx-auto btn-agregar"  id="agregar-distribucion"><img src="<?php echo e('/images/agregar-archivo.png'); ?>" width="40px" alt="img-agregar"> Editar Cliente</button>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/clientes/edit.blade.php ENDPATH**/ ?>