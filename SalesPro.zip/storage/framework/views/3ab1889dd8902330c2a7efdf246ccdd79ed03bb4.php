<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/recordatorios-table.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/alertas.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/recordatorios.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('estado')): ?>
    <div class="alert alert-success text-center" role="alert">
        <?php echo e(session('estado')); ?>

    </div>
<?php endif; ?>
<div class="row ml-5 ml-md-0">
    <div class="col-md-6 my-3">
        <h1 class="border-0 shadow p-3 mb-3" style="border-radius: 2rem;"> Recordatorios</h1>
        <img src="<?php echo e('/images/recordatorio-index.png'); ?>" alt="">
    </div>
    <div class="col-md-6 mt-5">
        <img src="<?php echo e('/images/recordatorios.png'); ?>" class="agregar-recordatorio" alt="" data-target="#agregar-recordatorio" data-toggle="modal">
        <p class="mt-2 font-weight-bold">Agregar Recordatorio
        </p>
    </div>
</div>

<!-- modal-->
<div class="modal fade" id="agregar-recordatorio" tabindex="-1" data-keyboard="false" aria-hidden="true" aria-labelledby="agregar-recordatorioLabel" data-backdrop="static">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2><img src="<?php echo e('/images/estatus.png'); ?>" alt="" class="mr-2">Nuevo Recordatorio</h2>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('recordatorio.agregar')); ?>" method="POST" novalidate name="formulario-recordatorio" id="formulario-recordatorio">
                <?php echo csrf_field(); ?>
                <p class="text-center font-weight-bold">Campos obligatorios <span class="text-danger">*</span></p>
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e('/images/editar.png'); ?>" class="mr-1 mb-3" alt="">
                        <label for="asunto">Asunto <span class="text-danger">*</span> </label>
                        <input type="text" name="asunto" id="asunto" class="form-control <?php $__errorArgs = ['asunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('asunto')); ?>">
                        <?php $__errorArgs = ['asunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mt-3">
                        <img src="<?php echo e('/images/fecha.png'); ?>" class="mr-1 mb-3" alt="">
                        <label for="fecha">Fecha Evento <span class="text-danger">*</span> </label>
                        <input type="datetime-local" name="fecha" id="fecha" value="<?php echo e(old('fecha')); ?>"class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mt-3">
                        <img src="<?php echo e('/images/show-prospecto-user.png'); ?>" class="mr-1 mb-3" alt="">
                        <label for="prospecto">Prospecto <span class="text-danger">*</span> </label>
                       <select name="prospecto_id" id="prospecto_id" class="form-control text-uppercase <?php $__errorArgs = ['prospecto_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">-- Seleccione --</option>
                        <?php $__currentLoopData = $prospectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prospecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($prospecto->id); ?>"<?php echo e(old('prospecto_id') == $prospecto->id ? 'selected': ''); ?> ><?php echo e($prospecto->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                    <?php $__errorArgs = ['prospecto_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6 mt-3">
                        <div class="form-group">
                            <img src="<?php echo e('/images/fecha.png'); ?>" alt="" class="mr-1 mb-3">
                            <label for="fecha_recordatorio">Fecha Recordatorio <span class="text-danger">*</span> </label>
                            <input type="datetime-local" name="fecha_recordatorio" id="fecha_recordatorio" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center mt-5">
                    <button type="submit" class="btn btn-dark mt-3 mr-3"><img src="<?php echo e('/images/agregar-archivo.png'); ?>" width="40px" alt=""> Agregar</button>
                    <button type="button" class="btn btn-primary mt-3 " data-dismiss="modal" ><img src="<?php echo e('/images/cerrar.png'); ?>" width="40px" alt=""> Cancelar</button>
                </div>

                </form>
            </div>
            <div class="modal-footer">

            </div>
        </div>

    </div>

</div>


<div class="contenido-recordatorios ml-5 ml-md-0">
    <table class="table w-100 display responsive nowrap" id="table-recordatorios">
        <thead>
            <tr>
                <th>#</th>
                <th>Asunto</th>
                <th>Fecha</th>
                <th>Prospecto</th>
                <th class="acciones">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $recordatorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recordatorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($recordatorio->id); ?></td>
                <td><?php echo e($recordatorio->asunto); ?></td>
                <td><?php echo e($recordatorio->fecha); ?></td>
                <td><?php echo e($recordatorio->prospecto->nombre); ?></td>
                <td class="acciones">
                    <a href="<?php echo e(route('recordatorio.show', ['recordatorio' => $recordatorio->id])); ?>" class="btn btn-dark my-2 d-block"><img src="<?php echo e('/images/show.png'); ?>" alt=""></a>

                    <a href="<?php echo e(route('recordatorio.editar', ['recordatorio' => $recordatorio->id])); ?>" class="btn btn-dark my-2 d-block"><img src="<?php echo e('/images/editar.png'); ?>" alt=""></a>

                    <form method="POST" id="eliminar-recordatorio" aria-modal="eliminar-recordatorio">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="button"  data-toggle="modal" data-placement="top" title="Eliminar recordatorio" onclick="eliminarRecordatorio(<?php echo e($recordatorio->id); ?>);" id="<?php echo e($recordatorio->id); ?>" class="btn btn-dark my-2 d-block w-100"><img src="<?php echo e('/images/eliminar.png'); ?>" alt=""></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/recordatorios/index.blade.php ENDPATH**/ ?>