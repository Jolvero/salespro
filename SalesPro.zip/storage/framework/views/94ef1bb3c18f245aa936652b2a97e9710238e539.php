<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/alertas.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/plantillas-table.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/plantillas.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('plantilla')): ?>
        <div class="alert alert-success text-center">
            <?php echo e(session('plantilla')); ?>

        </div>
    <?php endif; ?>

    <div class="row ml-5 ml-md-0">
        <div class="col-md-6">
            <h1 class="border-0 shadow p-3 mb-4" style="border-radius: 2rem;">Mis plantillas</h1>
            <img src="<?php echo e('/images/plantilla.png'); ?>" alt="" class="ml-5 mt-1">
        </div>

        <div class="col-md-6 mt-5 mt-md-0" data-aos="fade-up" data-aos-duration="1000">
            <img src="<?php echo e('/images/plantilla-add.png'); ?>" class="mt-0 ml-5 ml-md-0 agregar-prospecto" alt=""
                data-target="#agregar-plantilla" data-toggle="modal">
            <p class="mx-5 mx-md-0 mt-2">Agregar Plantilla</p>
        </div>
    </div>

    <div class="modal fade" id="agregar-plantilla" tabindex="-1" aria-hidden="true" data-backdrop="static"
        data-keyboard="false" aria-labelledby="agregar-plantillaLabel" role="dialog">

        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Nueva Plantilla</h2> <img src="<?php echo e('/images/plantilla.png'); ?>" width="50px"
                        class="ml-2" alt="">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>

                <div class="modal-body">
                    <form action="<?php echo e(route('plantilla.store')); ?>" class="formulario-crear" id="formulario"
                        enctype="multipart/form-data" method="POST" novalidate>
                        <p class="text-center font-weight-bold">Campos obligatorios <span class="text-danger">*</span></p>
                        <div class="row justify-content-center mt-3">
                            <?php echo csrf_field(); ?>

                            <div class="col-md-6">

                                <div class="form-group">
                                    <img src="<?php echo e('/images/nombre.png'); ?>" class="mr-1 mb-3" alt="">
                                    <label for="nombre">Nombre <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" id="nombre"
                                        value="<?php echo e(old('nombre')); ?>">

                                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"
                                            role="alert"><strong><?php echo e($message); ?></strong></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">

                                <div class="form-group">
                                    <img src="<?php echo e('/images/nombre.png'); ?>" class="mr-1 mb-3" alt="">
                                    <label for="plantilla">Plantilla <span class="text-danger">*</span></label>
                                    <textarea type="text" class="form-control <?php $__errorArgs = ['plantilla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="plantilla" id="plantilla"
                                        value="<?php echo e(old('plantilla')); ?>" style="height: 200px;"></textarea>

                                    <?php $__errorArgs = ['plantilla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"
                                            role="alert"><strong><?php echo e($message); ?></strong></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="form-group d-block">
                            <button type="submit" style="background-color:#1973b8; border:none;" type="submit"
                                class="boton text-white p-3 rounded d-block mx-auto btn-agregar"
                                id="agregar-distribucion"><img src="<?php echo e('/images/agregar-archivo.png'); ?>" width="40px"
                                    alt="img-agregar"> Agregar Plantilla</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="contenido-plantillas ml-5 ml-md-0">
        <table class="table w-100 display responsive nowrap" id="table-plantillas">
            <thead>
                <tr data-aos="fade-down" data-aos-duration="1000">
                    <th>#</th>
                    <th>Plantilla</th>
                    <th>Usuario</th>
                    <th class="acciones">Acciones</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $plantillas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plantilla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center" data-aos="fade-down" data-aos-duration="1000">
                    <td><?php echo e($plantilla->id); ?></td>
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <td>
                            <textarea name="actualizar-plantilla" id="<?php echo e($plantilla->id); ?>" onblur="actualizarPlantilla(this.value, <?php echo e($plantilla->id); ?>);" cols="30" rows="10"><?php echo e($plantilla->plantilla); ?></textarea>
                            </td>
                    </form>

                    <td><?php echo e($plantilla->user->name); ?></td>
                    <td class="acciones">
                        <a href="<?php echo e(route('plantilla.show',['plantilla' => $plantilla->id])); ?>" class="btn btn-dark my-2 d-block"><img src="<?php echo e('/images/show.png'); ?>" class="d-block mx-auto" alt=""></a>

                        <form method="POST" id="formulario-eliminar-plantilla">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="button" id="<?php echo e($plantilla->id); ?>" onclick="eliminarPlantilla(<?php echo e($plantilla->id); ?>);" data-toggle="tooltip" data-placement="top" title="Eliminar Plantilla" class="btn btn-dark my-2 d-block w-100"><img src="<?php echo e('/images/eliminar.png'); ?>" alt=""></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/plantillas/index.blade.php ENDPATH**/ ?>