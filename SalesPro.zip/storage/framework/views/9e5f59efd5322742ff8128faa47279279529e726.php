<?php $__env->startSection('content'); ?>

<div class="content ml-5 ml-md-0">
    <h2 class="font-weight-bold bg-white p-3"><?php echo e(__('Notificaciones')); ?></h2>

    <?php $__empty_1 = true; $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="p-3 border mt-3">
        <p class="my-0"><img src="<?php echo e('/images/show-prospecto-user.png'); ?>" alt=""> Se agregó un prospecto <span class="font-weight-bold"><?php echo e($notificacion->data['nombre']); ?></span></p>
        <p class="my-0">Empresa <span class="font-weight-bold"><?php echo e($notificacion->data['empresa']); ?></span></p>
        <div>

        <p class="my-0"><span class="font-weight-bold"><?php echo e($notificacion->created_at->diffForHumans()); ?></span></p>
    </div>
    <div>
        <a href="<?php echo e(route('prospecto.show', ['prospecto'=> $notificacion->data['id_prospecto']])); ?>" class="btn btn-dark text-uppercase font-weight-bold rounded-lg mt-3">Ver</a>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-center">No hay notificaciones nuevas</p>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/notificaciones/prospecto.blade.php ENDPATH**/ ?>