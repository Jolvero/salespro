<?php $__env->startSection('content'); ?>
<div class="content ml-5 ml-md-0">
    <h2 class="font-weight-bold bg-white p-3"><?php echo e(__('Notificaciones')); ?></h2>

    <?php $__empty_1 = true; $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="p-3 border mt-3 border-0 shadow" style="border-radius: 2rem;">
        <?php if($notificacion->data['redireccion'] == 'Cliente'): ?>
        <p>Nuevo Cliente agregado</p>
        <img src="<?php echo e('/images/show-prospecto-user.png'); ?>" alt="" width="64px;" class="img-fluid"><p class="font-weight-bold my-0">Empresa: <span class="font-weight-normal"><?php echo e($notificacion->data['empresa']); ?></span></p>
            <a href="<?php echo e(route('cliente.show', ['cliente' => $notificacion->data['id']])); ?>" class="btn btn-primary mb-2 mx-2 mt-2 font-weight-bold">Ver</a>
        <?php else: ?>
        <p class="mt-3">Actualización Prospecto</p>
        <img src="<?php echo e('/images/show-prospecto-user.png'); ?>" alt="" width="64px;" class="img-fluid"><p class="font-weight-bold my-0">Empresa: <span class="font-weight-normal"><?php echo e($notificacion->data['empresa']); ?></span></p> <a href="<?php echo e(route('prospecto.show', ['prospecto' => $notificacion->data['id_prospecto']])); ?>" class="btn btn-primary mb-2 mx-2 mt-2 font-weight-bold">Ver</a>
        <?php endif; ?>
        <div>

        <p class="my-0"><span class="font-weight-bold"><?php echo e($notificacion->created_at->diffForHumans()); ?></span></p>
    </div>
    <div class="">

    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-center">No hay notificaciones nuevas</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/notificaciones/index.blade.php ENDPATH**/ ?>