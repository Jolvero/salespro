<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/correos.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/alertas.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/prospectos.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/comentario.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('correo')): ?>
        <div class="alert alert-success text-center">
            <?php echo e(session('correo')); ?>

        </div>
    <?php endif; ?>

    <!-- Modal-->

    <?php if(count($cotizaciones) > 0): ?>
        <div class="modal fade" id="cotizaciones" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false"
            aria-labelledby="cotizacionesLabel">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content border-0 shadow" style="border-radius: 2rem;">
                    <div class="modal-header">
                        <h2><img src="<?php echo e('/images/cotizacion.png'); ?>" alt=""> Cotizaciones</h2>
                    </div>
                    <div class="modal-body mb-5 ">
                        <div class="row">
                            <?php $__currentLoopData = $cotizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cotizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="card card-body cotizaciones">
                                        <a href="<?php echo e(route('cotizacion.show', ['cotizacion' => $cotizacion->id])); ?>"
                                            class="btn btn-light text-decoration-none text-dark"
                                            target="blank"><?php echo e($cotizacion->nombre); ?></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button
                " class="btn btn-primary" data-dismiss="modal"
                            aria-label="Close"><img src="<?php echo e('/images/cerrar.png'); ?>" class="mr-1" alt="">
                            Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="modal fade" id="enviar-correo" tabindex="-1" data-keyboard="false" aria-hidden="true"
        aria-labelledby="enviar-correoLabel" data-backdrop="static">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h2><img src="<?php echo e('/images/correo.png'); ?>" alt=""> Correo</h2>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('prospecto.correo')); ?>" method="POST" novalidate enctype="multipart/form-data"
                        id="formulario-correo" name="formulario-correo">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 my-3 my-md-0">
                                <img src="<?php echo e('/images/destinatario.png'); ?>" class="mr-1 mb-3" alt="">
                                <label for="destinatario" class="font-weight-bold">Correo</label>
                                <input type="email" name="destinatario" id="destinatario"
                                    class="form-control <?php $__errorArgs = ['destinatario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e($prospecto->correo); ?>">
                                <?php $__errorArgs = ['destinatario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <img src="<?php echo e('/images/editar.png'); ?>" class="mr-1 mb-3" alt="">
                                <label for="destinatario" class="font-weight-bold">Asunto</label>
                                <input type="email" name="asunto" id="asunto"
                                    class="form-control <?php $__errorArgs = ['asunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('remitente')); ?>">
                                <?php $__errorArgs = ['asunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <img src="<?php echo e('/images/mensaje.png'); ?>" class="mr-1 my-3" alt="">
                                    <label for="mensaje" class="font-weight-bold">Mensaje</label>
                                    <textarea name="mensaje" class="form-control <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="mensaje" cols="30"
                                        rows="10"><?php echo e(old('mensaje')); ?></textarea>
                                    <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"
                                            role="alert"><strong><?php echo e($message); ?></strong></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <img src="<?php echo e('/images/adjuntar.png'); ?>" class="mr-1 my-3" alt="">
                                    <label for="adjunto" class="font-weight-bold">Adjunto</label>
                                    <input class="form-control" type="file" name="adjunto[]" multiple id="adjunto">
                                </div>

                                <div class="form-group">
                                    <img src="<?php echo e('/images/plantilla.png'); ?>" alt="" class="mr-1 my-3">
                                    <label for="">Plantillas</label>
                                    <select name="plantilla_id" id="plantilla_id" class="form-control">
                                        <option value="">-- Seleccione</option>
                                        <?php $__currentLoopData = $plantillas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plantilla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($plantilla->id); ?>" data-texto="<?php echo e($plantilla->plantilla); ?>"><?php echo e($plantilla->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                            </div>
                            <div class="col-md-12">
                                <div class="d-flex justify-content-center">
                                    <button type="submit" class="btn btn-dark mt-2 text-white" id="btn-enviar"><img
                                            src="<?php echo e('/images/agregar-archivo.png'); ?>" width="64px" alt="">
                                        Enviar</button>
                                    <button type="button" class="btn btn-primary mt-2 ml-4" data-dismiss="modal"><img
                                            src="<?php echo e('/images/cerrar.png'); ?>" alt=""> Cancelar</button>
                                </div>
                            </div>
                            <input type="hidden" name="nombre-prospecto" value="<?php echo e($prospecto->nombre); ?>">
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-between ml-5 ml-md-0">

        <div class="col-md-5" data-aos="flip-right" data-aos-duration="1000">
            <div class="card card-body">
                <img src="<?php echo e('/images/prospecto.show.png'); ?>" class="d-block mx-auto" alt="">
                <h2 class="text-center mt-3" id="prospecto"><?php echo e($prospecto->nombre); ?></h2>
            </div>

        </div>

        <div class="col-md-7" data-aos="flip-left" data-aos-duration="1000">
            <div class="card card-body">
                <p class="font-weight-bold"><img src="<?php echo e('/images/estatus.png'); ?>" class="mr-1" alt="">
                    Estatus:
                    <span class="font-weight-normal"><?php echo e($prospecto->estado->estado); ?></span>
                </p>
                <p class="font-weight-bold"><img src="<?php echo e('/images/servicios.png'); ?>" class="mr-1" alt="">
                    Servicio:
                    <span class="font-weight-normal"><?php echo e($prospecto->servicio->servicio); ?></span>
                </p>
                <p class="font-weight-bold"><img src="<?php echo e('/images/correo.png'); ?>" data-toggle="modal"
                        data-target="#enviar-correo" data-placement="top" title="Enviar Correo" class="mr-1 correo-img"
                        alt=""> Correo:
                    <span class="font-weight-normal"><?php echo e($prospecto->correo); ?></span>
                </p>
                <?php $__currentLoopData = $tarifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="list-unstyled components">
                        <div class="py-2">
                            <a href="#tarifa" data-toggle="collapse" aria-expanded="false"
                                class="dropdown-toggle sidebar-link collapsed item"><span> <img
                                        src="<?php echo e('/images/tarifa.png'); ?>" class="mr-1" alt="">Tarifa</span></a>
                        </div>

                        <ul class="sidebar-dropdown list-unstyled collapse" id="tarifa">
                            <li>
                                <?php if($tarifa->estatus_id == 2): ?>
                                    <p class="font-weight-bold"> Tarifa:
                                        <span class="font-weight-normal">$<?php echo e($tarifa->tarifa); ?></span>
                                    </p>
                                <?php endif; ?>

                                <?php if(Auth::user()->rol_id == 1 && $tarifa->estatus_id == 1): ?>
                                    <p class="font-weight-bold"> Tarifa:
                                        <span class="font-weight-normal">$<?php echo e($tarifa->tarifa); ?></span>
                                    </p>
                                    <div class="d-md-flex">
                                        <form method="POST" id="autorizar-tarifa">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button class=" btn-agregar text-white p-3 rounded mx-5" id="btn-autorizar"
                                                style="background-color: rgb(25, 115, 184); border: none;"
                                                type="button">Autorizar</button>

                                        </form>
                                    </div>
                                <?php endif; ?>


                            </li>
                        </ul>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <p class="font-weight-bold"><img src="<?php echo e('/images/show-prospecto-user.png'); ?>" class="mr-1"
                        alt=""> Usuario: <span class="font-weight-normal"><?php echo e($prospecto->usuario->name); ?></span>

                </p>
                <section class="timeline mt-5">
                    <?php if(count($comentarios) > 0): ?>
                        <h2 class="text-center font-weight-bold">Seguimientos</h2>
                        <ul>
                            <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="in-view" data-aos="fade-left">
                                    <div class="contenido-comentario">
                                        <?php
                                            $fecha = $comentario->updated_at;
                                        ?>
                                        <time>Comentario</time>
                                        <h3 class=""><span
                                                class="font-weight-bold"></span><?php echo e($comentario->comentario); ?></h3>
                                        <formatear-fecha fecha="<?php echo e($fecha); ?>"></formatear-fecha>

                                        <form method="POST" id="formulario-comentario-update">
                                            <?php echo csrf_field(); ?>
                                            <textarea name="comentario" id="<?php echo e($comentario->id); ?>" class="comentario" cols="30" style="height: 100px; width:150px;" rows="10" ><?php echo e($comentario->comentario); ?></textarea>
                                        </form>

                                        <form method="POST" id="formulario-eliminar-comentario">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" id="<?php echo e($comentario->id); ?>" onclick="eliminarComentario(<?php echo e($comentario->id); ?>);" data-toggle="tooltip" data-placement="top" title="Eliminar Comentario" class="btn btn-dark my-2 d-block w-100"><img src="<?php echo e('/images/eliminar.png'); ?>" alt=""></button>
                                            </form>


                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    </ul>
                </section>
            </div>

        </div>
    </div>

    <?php if(count($cotizaciones) > 0): ?>
        <div class="elementos-adicionales mt-5 ml-5 ml-md-0">
            <button class="btn btn-light text-dark" data-target="#cotizaciones" data-toggle="modal"><img
                    src="<?php echo e('/images/show-cotizaciones.png'); ?>"class="mr-2" alt=""> Documentos</button>
        </div>
    <?php endif; ?>
    <input type="hidden" id="id" value="<?php echo e($prospecto->tarifa_id); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/prospectos/show.blade.php ENDPATH**/ ?>