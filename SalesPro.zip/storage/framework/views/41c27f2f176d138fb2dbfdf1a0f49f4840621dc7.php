<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/recordatorios.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row ml-5 ml-md-0 mb-3">
        <div class="col-md-6 my-3">
            <h1> Editar Recordatorios</h1>
            <img src="<?php echo e('/images/recordatorio-index.png'); ?>" alt="">
        </div>
    </div>
    <form action="<?php echo e(route('recordatorio.update', ['recordatorio' => $recordatorio->id])); ?>" method="POST" name="formulario-recordatorio" id="formulario-recordatorio">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center">

            <div class="col-md-6">
                <div class="form-group">
                    <img src="<?php echo e('/images/editar.png'); ?>" class="mr-1 mb-3"alt="">
                    <label for="asunto">Asunto</label>
                    <input type="text" name="asunto" id="asunto"
                        class="form-control <?php $__errorArgs = ['asunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($recordatorio->asunto); ?>">
                    <?php $__errorArgs = ['asunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="col-md-6">
                <img src="<?php echo e('/images/fecha.png'); ?>" class="mr-1 mb-3" alt="">
                <label for="fecha">Fecha Evento</label>
                <input type="datetime-local" name="fecha" id="fecha"
                    value="<?php echo e($recordatorio->fecha); ?>"class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mt-3">
                <img src="<?php echo e('/images/show-prospecto-user.png'); ?>" class="mr-1 mb-3" alt="">
                <label for="prospecto">Prospecto</label>
                <select name="prospecto_id" id="prospecto_id"
                    class="form-control <?php $__errorArgs = ['prospecto_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">-- Seleccione --</option>
                    <?php $__currentLoopData = $prospectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prospecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($prospecto->id); ?>"<?php echo e($recordatorio->prospecto_id == $prospecto->id ? 'selected' : ''); ?>>
                            <?php echo e($prospecto->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <?php $__errorArgs = ['prospecto_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-6 mt-3">
                <div class="form-group">
                    <img src="<?php echo e('/images/fecha.png'); ?>" alt="" class="mr-1 mb-3">
                    <label for="fecha_recordatorio">Fecha Recordatorio</label>
                    <input type="date" name="fecha_recordatorio" id="fecha_recordatorio"
                        value="<?php echo e($recordatorio->fecha_recordatorio); ?>" class="form-control">
                </div>
            </div>

            <div class="d-flex justify-content-center mt-5">
                <button type="submit" class="btn btn-dark mt-3 mr-3"><img src="<?php echo e('/images/agregar-archivo.png'); ?>"
                        width="40px" alt=""> Actualizar</button>
            </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/recordatorios/edit.blade.php ENDPATH**/ ?>