<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/clientes.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/clientes-tables.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row ml-5 ml-md-0">
    <div class="col-md-6 my-5">
        <h1 class="font-weight-bold border-0 shadow p-3" style="border-radius: 2rem;">Mis Clientes</h1>
        <img src="<?php echo e('/images/clientes.png'); ?>" class="mt-4" alt="">
    </div>


</div>

<div class="contenido-clientes">
    <table class="table w-100 display responsive nowrap ml-5 ml-md-0" id="table-clientes">
        <thead>
            <tr data-aos="fade-down" data-aos-duration="1000" class="text-center">
                <th>#</th>
                <th>Nombre</th>
                <th>Prospectador</th>
                <th class="acciones">Acciones</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center" data-aos="fade-down" class="text-center" data-aos-duration="1000">
                <td><?php echo e($cliente->id); ?></td>
                <td><?php echo e($cliente->nombre); ?></td>
                <td><?php echo e($cliente->usuario->name); ?></td>
                <td class="acciones">
                    <a href="<?php echo e(route('cliente.show',['cliente' => $cliente->id])); ?>" class="btn btn-dark my-2 d-block"><img src="<?php echo e('/images/show.png'); ?>" class="d-block mx-auto" alt=""></a>

                    <a href="<?php echo e(route('cliente.editar',['cliente' => $cliente->id])); ?>" class="btn btn-dark my-2 d-block"><img src="<?php echo e('/images/editar.png'); ?>" class="d-block mx-auto my-1" alt=""></a>

                    <form method="POST" id="eliminar-cliente">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="button" onclick="eliminarCliente(<?php echo e($cliente->id); ?>);" data-toggle="tooltop" data-placement="top" title="Eliminar cliente" id="<?php echo e($cliente->id); ?>" class="btn btn-dark my-2 d-block w-100"><img src="<?php echo e('/images/eliminar.png'); ?>" alt=""></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/clientes/index.blade.php ENDPATH**/ ?>