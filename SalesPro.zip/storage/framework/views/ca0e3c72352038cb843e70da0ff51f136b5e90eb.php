<p><?php echo e($mensajes); ?></p>

<?php $__currentLoopData = $adjuntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjunto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<img src="<?php echo e($adjunto); ?>" alt="" class="mt-4 mb-5">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<img src="http://127.0.0.1:8000/images/<?php echo e($firmas); ?>.png" alt="" class="mt-5">

<?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/correos/show-mailing.blade.php ENDPATH**/ ?>