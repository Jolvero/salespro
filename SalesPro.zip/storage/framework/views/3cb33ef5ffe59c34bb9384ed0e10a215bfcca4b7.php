<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/recordatorios.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/dashboard.js')); ?>" defer></script>



<!-- Inventario -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TECH-LOG\Desktop\SalesPro\resources\views/dashboard/index.blade.php ENDPATH**/ ?>