<p>{{$mensajes}}</p>

@foreach ($adjuntos as $adjunto)
<img src="{{$adjunto}}" alt="" class="mt-4 mb-5">
@endforeach

<img src="http://127.0.0.1:8000/images/{{$firmas}}.png" alt="" class="mt-5">

