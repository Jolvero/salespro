@extends('layouts.app')
@section('scripts')
<script src="{{asset('js/app.js')}}" defer  ></script>
@section('content')
@endsection
