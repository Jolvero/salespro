<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;

class ClienteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        // DB::table('clientes')->insert([
        //     'cliente' => Crypt::encryptString('CLIENTE 1'),
        //     'user_id' => 1

        // ]);

        // DB::table('clientes')->insert([
        //     'cliente' => Crypt::encryptString('CLIENTE 2'),
        //     'user_id' => 1
        // ]);

        // DB::table('clientes')->insert([
        //     'cliente' => Crypt::encryptString('CLIENTE 3'),
        //     'user_id' => 1

        // ]);

        // DB::table('clientes')->insert([
        //     'cliente' => Crypt::encryptString('CLIENTE 4'),
        //     'user_id' => 1

        // ]);
    }
}
